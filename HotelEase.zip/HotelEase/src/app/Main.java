package app;

import main.models.Hotel;

public class Main {
    public static void main(String[] args) {
        // Crear datos de prueba
        Hotel hotel = DataLoader.loadHotelData();

        // Ejecutar menú principal
        Menu.start(hotel);
    }
}