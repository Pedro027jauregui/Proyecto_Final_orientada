package app;

import main.models.*;
import util.ConsoleUtils;

import java.util.List;
import java.util.Scanner;

public class Menu {
    public static void start(Hotel hotel) {
        while (true) {
            ConsoleUtils.printLine("\n=== Sistema de Reservas de Hotel ===");
            ConsoleUtils.printLine("1. Ver todas las habitaciones");
            ConsoleUtils.printLine("2. Crear una reserva");
            ConsoleUtils.printLine("3. Ver reservas");
            ConsoleUtils.printLine("4. Salir");

            int choice = ConsoleUtils.readInt("Introduce tu opción: ");
            switch (choice) {
                case 1 -> showRooms(hotel);
                case 2 -> createReservation(hotel);
                case 3 -> viewReservations(hotel);
                case 4 -> {
                    ConsoleUtils.printLine("Saliendo del sistema...");
                    return;
                }
                default -> ConsoleUtils.printLine("Opción no válida. Intenta de nuevo.");
            }
        }
    }

    private static void showRooms(Hotel hotel) {
        ConsoleUtils.printLine("=== Habitaciones Disponibles ===");
        for (Room room : hotel.getAvailableRooms()) {  // Usamos getAvailableRooms en lugar de getRooms
            ConsoleUtils.printLine(room.toString());
        }
    }

    private static void createReservation(Hotel hotel) {
        ConsoleUtils.printLine("=== Crear una Reserva ===");
        Scanner scanner = new Scanner(System.in);

        // Obtener detalles del huésped
        System.out.println("Nombre del huésped: ");
        String guestName = scanner.nextLine();
        System.out.println("Correo electrónico del huésped: ");
        String guestEmail = scanner.nextLine();
        Guest guest = new Guest(guestName, guestEmail);

        // Seleccionar habitación
        showRooms(hotel);
        System.out.println("Número de habitación seleccionada: ");
        String roomNumber = scanner.nextLine().toUpperCase();
        Room selectedRoom = hotel.getRoomByNumber(roomNumber);
        if (selectedRoom == null) {
            ConsoleUtils.printLine("Habitación no encontrada. Intenta de nuevo.");
            return;
        }

        // Seleccionar servicios adicionales (opcional)
        ConsoleUtils.printLine("¿Desea agregar servicios adicionales? (S/N)");
        String addServices = scanner.nextLine().toUpperCase();
        AdditionalService[] services = new AdditionalService[0];
        if (addServices.equals("S")) {
            services = selectAdditionalServices();
        }

        // Elegir fechas de la reserva
        ConsoleUtils.printLine("Fecha de inicio (yyyy-mm-dd): ");
        String startDate = scanner.nextLine();
        ConsoleUtils.printLine("Fecha de fin (yyyy-mm-dd): ");
        String endDate = scanner.nextLine();
        int nights = ConsoleUtils.calculateNights(startDate, endDate);

        // Crear la reserva
        Reservation reservation = new Reservation(selectedRoom, startDate, endDate, List.of(services), guest);
        hotel.addReservation(reservation);
        ConsoleUtils.printLine("Reserva creada exitosamente:");
        ConsoleUtils.printLine(reservation.toString());
    }

    private static AdditionalService[] selectAdditionalServices() {
        ConsoleUtils.printLine("=== Servicios Adicionales Disponibles ===");
        ConsoleUtils.printLine("1. Desayuno ($15)");
        ConsoleUtils.printLine("2. Traslado al aeropuerto ($50)");
        ConsoleUtils.printLine("3. Masaje ($70)");
        int choice = ConsoleUtils.readInt("Elige un servicio: ");
        switch (choice) {
            case 1 -> {
                return new AdditionalService[]{new BreakfastService()};
            }
            case 2 -> {
                return new AdditionalService[]{new TransportService()};
            }
            case 3 -> {
                return new AdditionalService[]{new SpaService()};
            }
            default -> {
                ConsoleUtils.printLine("Opción no válida.");
                return new AdditionalService[0];
            }
        }
    }

    private static void viewReservations(Hotel hotel) {
        ConsoleUtils.printLine("=== Ver Reservas ===");
        if (hotel.getReservations().isEmpty()) {
            ConsoleUtils.printLine("No hay reservas actuales.");
            return;
        }
        for (Reservation reservation : hotel.getReservations()) {
            ConsoleUtils.printLine(reservation.toString());
        }
    }
}
