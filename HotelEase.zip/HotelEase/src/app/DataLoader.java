package app;

import main.models.*;

import java.util.List;

public class DataLoader {
    public static Hotel loadHotelData() {
        // Crear un hotel
        Hotel hotel = new Hotel("Grand Plaza Hotel");

        // Agregar habitaciones al hotel
        hotel.addRoom(new SingleRoom("S101", 50.0));  // Habitación individual
        hotel.addRoom(new DoubleRoom("D201", 80.0)); // Habitación doble
        hotel.addRoom(new SuiteRoom("S301", 150.0)); // Suite

        // Devolver el hotel con los datos cargados
        return hotel;
    }
}
