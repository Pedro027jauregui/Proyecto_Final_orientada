package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class ConsoleUtils {
    private static final Scanner scanner = new Scanner(System.in);

    public static String readString(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextLine()) {
            scanner.nextLine(); // Limpiar cualquier dato sobrante en el buffer
        }
        return scanner.nextLine();
    }

    public static int readInt(String prompt) {
        System.out.println(prompt);
        return scanner.nextInt();
    }

    public static void printLine(String message) {
        System.out.println(message);
    }

    // Método para calcular el número de noches entre dos fechas
    public static int calculateNights(String startDate, String endDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Convertir las fechas de String a LocalDate
        LocalDate start = LocalDate.parse(startDate, formatter);
        LocalDate end = LocalDate.parse(endDate, formatter);

        // Calcular la diferencia en días
        long daysBetween = ChronoUnit.DAYS.between(start, end);

        // Si la diferencia es negativa, se podría manejar el error o devolver 0
        if (daysBetween < 0) {
            return 0; // O lanzar una excepción dependiendo de la lógica del sistema
        }

        return (int) daysBetween;
    }
}
