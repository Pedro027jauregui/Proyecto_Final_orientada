package main.interfaces;

public interface Reservable {
    // Método para verificar si un elemento está disponible para su reserva
    boolean checkAvailability();

    // Método para calcular el costo total de la reserva
    double calculateCost(int nights); // El parámetro es el número de noches reservadas
}
