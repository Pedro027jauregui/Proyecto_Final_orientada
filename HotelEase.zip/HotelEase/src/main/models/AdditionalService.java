package main.models;

import main.interfaces.Reservable;

public abstract class AdditionalService implements Reservable {
    private String serviceName;  // Nombre del servicio
    private double price;        // Precio del servicio

    // Constructor
    public AdditionalService(String serviceName, double price) {
        this.serviceName = serviceName;
        this.price = price;
    }

    // Implementación de la interfaz Reservable
    @Override
    public boolean checkAvailability() {
        // En este caso, siempre está disponible el servicio adicional, pero puede ser modificado según sea necesario
        return true;
    }

    @Override
    public double calculateCost(int nights) {
        // El costo no depende de las noches para un servicio adicional, solo se calcula su precio
        return price;
    }

    // Getters y Setters
    public String getServiceName() {
        return serviceName;
    }

    public double getPrice() {
        return price;
    }

    // Representación en cadena de texto
    @Override
    public String toString() {
        return "Service: " + serviceName + " | Price: $" + price;
    }
}
