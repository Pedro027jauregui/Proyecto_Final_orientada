package main.models;

public class Guest {
    private String name;       // Nombre del huésped
    private String email;      // Correo electrónico del huésped

    // Constructor
    public Guest(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters y Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Representación en cadena de texto
    @Override
    public String toString() {
        return "Guest Name: " + name + " | Email: " + email;
    }
}
