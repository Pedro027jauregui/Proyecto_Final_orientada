package main.models;

public class TransportService extends AdditionalService {
    // Constructor
    public TransportService() {
        super("Transport", 50.0);
    }
}
