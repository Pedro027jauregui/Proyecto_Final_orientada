package main.models;

import util.ConsoleUtils;

import java.util.ArrayList;
import java.util.List;

public class Reservation {

    private Room room;
    private String startDate;
    private String endDate;
    private List<AdditionalService> services;  // Servicios adicionales seleccionados por el cliente
    private Guest guest;  // Información del huésped
    private int nights;

    // Constructor
    public Reservation(Room room, String startDate, String endDate, List<AdditionalService> services, Guest guest) {
        this.room = room;
        this.startDate = startDate;
        this.endDate = endDate;
        this.services = services;
        this.guest = guest;
        this.nights = ConsoleUtils.calculateNights(startDate, endDate); // Calculamos el número de noches
    }

    // Getters y Setters
    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public List<AdditionalService> getServices() {
        return services;
    }

    public void setServices(List<AdditionalService> services) {
        this.services = services;
    }

    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public int getNights() {
        return nights;
    }

    public void setNights(int nights) {
        this.nights = nights;
    }

    // Método para calcular el costo total de la reserva
    public double calculateTotalCost() {
        double totalCost = room.calculateCost(nights);  // Costo de la habitación
        for (AdditionalService service : services) {
            totalCost += service.calculateCost(nights);  // Costo de los servicios adicionales
        }
        return totalCost;
    }

    @Override
    public String toString() {
        return "Detalles de la Reserva:\n" +
                "Habitación: " + room + "\n" +
                "Huésped: " + guest.getName() + "\n" +
                "Fechas: " + startDate + " a " + endDate + "\n" +
                "Costo Total: $" + calculateTotalCost();
    }

}
