package main.models;

public class SpaService extends AdditionalService {
    // Constructor
    public SpaService() {
        super("Spa", 50.000);
    }
}
