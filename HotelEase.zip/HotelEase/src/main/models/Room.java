package main.models;

import main.interfaces.Reservable;

import java.util.Objects;

public abstract class Room implements Reservable {
    private String roomNumber; // Número de habitación
    private double pricePerNight; // Precio por noche
    private boolean isAvailable; // Disponibilidad

    // Constructor
    public Room(String roomNumber, double pricePerNight) {
        this.roomNumber = roomNumber;
        this.pricePerNight = pricePerNight;
        this.isAvailable = true; // Por defecto, la habitación está disponible
    }

    // Implementación de la interfaz Reservable

    // Verificar disponibilidad de la habitación
    @Override
    public boolean checkAvailability() {
        return isAvailable;
    }

    // Calcular el costo total basado en las noches
    @Override
    public double calculateCost(int nights) {
        return pricePerNight * nights;
    }

    // Método para cambiar la disponibilidad de la habitación
    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    // Getters y Setters
    public String getRoomNumber() {
        return roomNumber;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    // Método equals para comparar dos habitaciones
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Room room = (Room) obj;
        return Objects.equals(roomNumber, room.roomNumber); // Compara por número de habitación
    }

    // Método hashCode para garantizar la coherencia con equals
    @Override
    public int hashCode() {
        return Objects.hash(roomNumber);
    }

    @Override
    public String toString() {
        return "Número de Habitación: " + roomNumber +
                " | Precio por Noche: $" + pricePerNight +
                " | Disponible: " + (isAvailable ? "SI" : "NO");
    }

}