package main.models;

public class DoubleRoom extends Room {
    // Constructor
    public DoubleRoom(String roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}
