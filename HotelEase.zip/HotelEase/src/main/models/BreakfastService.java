package main.models;

public class BreakfastService extends AdditionalService {
    // Constructor
    public BreakfastService() {
        super("Breakfast", 15.000);
    }
}
