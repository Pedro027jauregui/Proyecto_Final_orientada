package main.models;

public class SuiteRoom extends Room {
    // Constructor
    public SuiteRoom(String roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}