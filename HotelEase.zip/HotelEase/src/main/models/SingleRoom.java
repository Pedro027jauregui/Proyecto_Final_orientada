package main.models;

public class SingleRoom extends Room {
    // Constructor
    public SingleRoom(String roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}
