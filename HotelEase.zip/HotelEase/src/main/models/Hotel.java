package main.models;

import util.ConsoleUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Hotel {
    private String name; // Nombre del hotel
    private List<Room> rooms; // Lista de habitaciones
    private List<Reservation> reservations; // Lista de reservas

    public Hotel(String name) {
        this.name = name;
        this.rooms = new ArrayList<>();
        this.reservations = new ArrayList<>();
    }

    // Método para obtener una habitación por su número
    public Room getRoomByNumber(String roomNumber) {
        for (Room room : rooms) {
            if (Objects.equals(room.getRoomNumber(), roomNumber)) {
                return room;
            }
        }
        return null; // Si no se encuentra la habitación, se devuelve null
    }

    // Método para agregar una nueva habitación al hotel
    public void addRoom(Room room) {
        rooms.add(room);
    }

    // Método para agregar una nueva reserva al hotel
    public void addReservation(Reservation reservation) {
        Room room = reservation.getRoom();

        // Verifica si la habitación está disponible
        if (room.checkAvailability()) {
            reservations.add(reservation);
            room.setAvailable(false); // Marca la habitación como no disponible
        } else {
            ConsoleUtils.printLine("La habitación " + room.getRoomNumber() + " ya está reservada.");
        }
    }

    // Método para obtener solo las habitaciones disponibles
    public List<Room> getAvailableRooms() {
        // Obtiene las habitaciones reservadas a partir de las reservas
        List<Room> reservedRooms = reservations.stream()
                .map(Reservation::getRoom) // Obtiene la habitación asociada a cada reserva
                .collect(Collectors.toList());

        // Filtra las habitaciones disponibles
        return rooms.stream()
                .filter(room -> !reservedRooms.contains(room)) // Excluye las habitaciones reservadas
                .collect(Collectors.toList());
    }


    // Métodos getter
    public List<Room> getRooms() {
        return rooms; // Retorna todas las habitaciones (siempre disponible para uso interno)
    }

    public List<Reservation> getReservations() {
        return reservations; // Retorna todas las reservas
    }

    public String getName() {
        return name; // Retorna el nombre del hotel
    }
}
